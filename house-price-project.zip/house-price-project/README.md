# House Price Model — API + Website

The backend now trains directly from `USA_Housing.csv` when it starts. Nothing about the model — coefficients, feature ranges, R²/MAE/RMSE — is hardcoded anywhere. The website fetches all of it from the API on page load.

**This means:** if you change the data (edit `USA_Housing.csv`, add rows, etc.), you don't touch `index.html` at all. Just update the CSV and restart (or hit `/retrain`) — the site picks up the new numbers automatically.

## How it fits together

```
USA_Housing.csv  →  backend/app.py (trains on startup)  →  GET /model-info  →  index.html renders sliders, impact bars, metrics
                                                          →  POST /predict   →  index.html "Predict directly on the server" button
```

## 1. Deploy the backend (Render — free tier)

1. Push the contents of `backend/` to a GitHub repo — `app.py`, `requirements.txt`, `Procfile`, and `USA_Housing.csv`.
2. Go to [render.com](https://render.com) → **New** → **Web Service** → connect the repo.
3. Settings:
   - **Runtime:** Python 3
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app:app`
4. Deploy. You'll get a URL like `https://house-price-api.onrender.com`.
5. Check it: `curl https://house-price-api.onrender.com/model-info` should return JSON with coefficients and metrics.

Render's free tier sleeps after inactivity — the first request after idling can take ~30 seconds.

## 2. Point the website at your API

In `index.html`, near the top of the `<script>` tag:

```js
const API_BASE_URL = "";
```

Set it to your deployed URL:

```js
const API_BASE_URL = "https://house-price-api.onrender.com";
```

## 3. Deploy the website

Drag `index.html` into [Netlify Drop](https://app.netlify.com/drop), or push it to a repo and enable GitHub Pages.

## Updating the data later

**Option A — redeploy (simplest):** replace `backend/USA_Housing.csv` in your repo with the new file, push. Render redeploys and retrains automatically on startup.

**Option B — retrain without redeploying:** if you can update the CSV file directly on the server (e.g. via SSH or a file upload you add later), call:

```
POST /retrain
```

This reloads the CSV and retrains in place — the very next `/model-info` and `/predict` calls use the new model. No restart needed.

Either way, `index.html` never needs to change — it always reflects whatever the API currently reports.

## API reference

**GET `/model-info`** — everything the frontend needs to render itself.
```json
{
  "intercept": 1229576.99,
  "feature_order": ["income", "age", "rooms", "bedrooms", "population"],
  "features": {
    "income": { "label": "Avg. Area Income", "coefficient": 231741.88, "mean": 68585.84, "std": 10702.92, "min": 17796.63, "max": 107701.75 },
    "...": "..."
  },
  "metrics": { "r2": 0.918, "mae": 80879.1, "rmse": 100444.06, "n_train": 4000, "n_test": 1000 }
}
```

**POST `/predict`**
```json
{ "income": 68583, "age": 5.98, "rooms": 6.99, "bedrooms": 3.98, "population": 36163 }
```
→
```json
{ "predicted_price": 1232710.77, "inputs": { ... } }
```

**POST `/retrain`** — reloads `USA_Housing.csv` and retrains in place.

## Feature name mapping

If you rename a column in the CSV, update `FEATURE_MAP` at the top of `app.py` — that's the only place column names are referenced:

```python
FEATURE_MAP = {
    "income": "Avg. Area Income",
    "age": "Avg. Area House Age",
    "rooms": "Avg. Area Number of Rooms",
    "bedrooms": "Avg. Area Number of Bedrooms",
    "population": "Area Population",
}
```
